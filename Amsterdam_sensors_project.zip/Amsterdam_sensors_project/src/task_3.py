#!/usr/bin/env python3
'''
Std. no: 2778835
'''


from typing import List, Union


from typing import List

def is_min_heap(array: List[int]) -> bool:
    '''
    Check if the given array represents a min-heap.

    ### Parameters
    `array`: A list of integers

    ### Return
    `True` if `array` is a min-heap, `False` otherwise.
    '''

    def is_min_heap_recursive(index: int) -> bool:
        if index >= len(array):
            return True  # An empty subtree is a valid min-heap.

        left_child_index = 2 * index + 1
        right_child_index = 2 * index + 2

        if (left_child_index < len(array) and
                array[left_child_index] < array[index]):
            return False

        if (right_child_index < len(array) and
                array[right_child_index] < array[index]):
            return False

        return (is_min_heap_recursive(left_child_index) and
                is_min_heap_recursive(right_child_index))

    return is_min_heap_recursive(0)



# def is_min_heap(array: List[int]) -> str:
#     '''
#     Determine if `array` represents a min heap
#
#     ### Parameters
#     `array`: An array of positive integers
#
#     ### Return
#     A string in the format "1 | True" or "0 | False" for if the `array` is a min heap
#     '''
#
#     # Iterate through the array from the last parent node to the root
#     for i in range(len(array) // 2 - 1, -1, -1):
#         # Check if the current element is greater than its left child
#         if array[i] > array[2 * i + 1]:
#             return "0 | False"  # Not a min heap
#
#         # Check if the current element is greater than its right child
#         if 2 * i + 2 < len(array) and array[i] > array[2 * i + 2]:
#             return "0 | False"  # Not a min heap
#
#     return "1 | True"  # It's a min heap


# print(is_min_heap([1, 2, 5, 3, 4, 6, 7]))  # Should return True (it's a min-heap)
# print(is_min_heap([1, 3, 2, 4, 5, 6, 7]))  # Should return True (it's a min-heap)
# print(is_min_heap([1, 2, 3, 4, 5, 6, 7]))  # Should return True (it's a min-heap)
# print(is_min_heap([7, 6, 5, 4, 3, 2, 1]))  # Should return False (not a min-heap)
# print(is_min_heap([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]))  # Should return True (it's a min-heap)

