#!/usr/bin/env python3
'''
Std. no: 2778835
'''

from typing import List
import bisect

def find_occurrences(array: List[int], n: int) -> int:
    '''
    Find the number of occurrences of `n` in the `array` list

    ### Parameters
    `array`: An  **ordered** array of positive integers

    `n`: int

    ### Return
    The number of occurrences of `n` in `array`
    '''

    # Use binary search to find the first occurrence of n
    first_occurrence_index = bisect.bisect_left(array, n)

    # If n is not found, return 0 occurrences
    if first_occurrence_index == len(array) or array[first_occurrence_index] != n:
        return 0

    # Use binary search to find the last occurrence of n
    last_occurrence_index = bisect.bisect_right(array, n) - 1

    # Calculate the count of occurrences
    count = last_occurrence_index - first_occurrence_index + 1

    return count


# print(find_occurrences([1, 1, 2, 3, 4, 4, 4, 8, 10], 1))  # Should return 2
# print(find_occurrences([1, 1, 2, 3, 4, 4, 4, 8, 10], 4))  # Should return 3
# print(find_occurrences([1, 1, 2, 3, 4, 4, 4, 8, 10], 5))  # Should return 0
# print(find_occurrences([1, 2, 3, 4, 5, 6], 3))  # Should return 1
# print(find_occurrences([1, 1, 1, 1, 1, 1], 1))  # Should return 6



