# #!/usr/bin/env python3
# '''
# Std. no: 2778835
# '''
#
#
# from typing import List
#
#
# def smallest_subarray_length(array: List[int], k: int) -> int:
#     '''
#     Find the length of the smallest sub-array of `array`
#         whose sum of elements is greater than `k`
#
#     ### Parameters
#     `array`: An array of positive integers
#
#     `k`: int
#
#     ### Return
#     The length of the smallest sub-array
#     '''
#
#     if not array:
#         return 0
#
#     n = len(array)
#     min_length = n + 1
#     current_sum = 0
#     left, right = 0, 0
#
#     while right < n:
#         current_sum += array[right]
#
#         while current_sum > k:
#             min_length = min(min_length, right - left + 1)
#             current_sum -= array[left]
#             left += 1
#
#         right += 1
#
#     return min_length if min_length != n + 1 else 0
#
# # Tests:
# print(smallest_subarray_length([1, 2, 3, 4, 5, 6, 7, 8], 20))  # Should return 3
# print(smallest_subarray_length([1, 2, 3, 4, 5], 11))  # Should return 3
# print(smallest_subarray_length([1, 2, 3, 4, 5], 15))  # Should return 5
# print(smallest_subarray_length([5, 5, 5, 5, 5], 20))  # Should return 4
# print(smallest_subarray_length([1, 2, 3, 4, 5], 100))  # Should return 0

# !/usr/bin/env python3
'''
Std. no: 2778835
'''

from typing import List


def smallest_subarray_length(array: List[int], k: int) -> int:
    if not array:
        return 0

    # Initialize variables for the sliding window
    left, right = 0, 0
    current_sum = array[0]
    min_length = float('inf')

    while right < len(array):
        # If the current sum is greater than or equal to k, update min_length
        if current_sum >= k:
            min_length = min(min_length, right - left + 1)
            # Move the left pointer to the right to shrink the window
            current_sum -= array[left]
            left += 1
        else:
            # If the current sum is less than k, expand the window to the right
            right += 1
            if right < len(array):
                current_sum += array[right]

    # If min_length is still float('inf'), no subsequence was found
    return min_length if min_length != float('inf') else 0

result = smallest_subarray_length([1, 2, 3, 4, 5, 6, 7, 8], 20)
print(result)  # Output: 3
result1 = smallest_subarray_length([1, 2, 3, 4, 5, 6, 7, 8], 100)
print(result1)  # Output: 0
result2 = smallest_subarray_length([10, 20, 30, 40, 50], 45)
print(result2)  # Output: 1
result3 = smallest_subarray_length([10, 20, 30, 40, 50], 110)
print(result3)  # Output: 3
result4 = smallest_subarray_length([5, 2, 1, 3, 4, 6, 8], 12)
print(result4)  # Output: 2