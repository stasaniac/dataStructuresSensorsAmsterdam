#!/usr/bin/env python3

from typing import Callable, List, Union
import time
import pytest
import logging
from os import path

import cg_pytest_reporter as cg_pytest


from src import task_1, task_2, task_3
import error


logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger('logger')
root_dir = path.dirname(path.abspath(__file__))


def run(testcase: str, time_limit: float,
        func: Callable[[List[int], int], int]):

    # Open test files and prepare input/answer data
    input_file = open(f"{root_dir}/{testcase}.in", "r")
    answer = int(open(f"{root_dir}/{testcase}.ans", "r").readline().rstrip())

    # Create `input_l: list[tuple[int,int,int]]` from the test file data
    data: List[str] = input_file.readline().split(' ')
    input_l: List[int] = [int(d) for d in data]
    k: int = int(input_file.readline())

    # Run the `sort` function and measure execution time
    start_time = time.time()
    result: int = func(input_l, k)
    end_time = time.time()

    # Check that the execution is not above limit
    exec_time = end_time - start_time
    if exec_time > time_limit:
        raise error.Timeout(time_limit, exec_time)
    log.info(f'Call to {func.__name__} took {exec_time}s')

    # Check that `sort` returned
    if result is None:
        raise error.NoOutput()

    # Check that return is list[int]
    if not isinstance(result, int):
        raise error.WrongType(int)

    # Check answer
    if result != answer:
        raise error.WrongAnswer(result, answer)


@pytest.mark.task_1
@pytest.mark.timeout(20)
@cg_pytest.suite_name('Task 1')
@cg_pytest.suite_weight(0.75)
class TestTask1:

    @cg_pytest.description('Array of length 10')
    def test_1(self):
        run("testcases/task_1/10", 20,
            task_1.smallest_subarray_length)

    @cg_pytest.description('Array of length 10_000')
    def test_2(self):
        run("testcases/task_1/10_000",
            20, task_1.smallest_subarray_length)

    @cg_pytest.description('Array of length 100_000')
    def test_3(self):
        run("testcases/task_1/100_000",
            20, task_1.smallest_subarray_length)

    @cg_pytest.description('Array of length 1_000_000')
    def test_4(self):
        run("testcases/task_1/1_000_000",
            20, task_1.smallest_subarray_length)


@pytest.mark.task_2
@pytest.mark.timeout(15)
@cg_pytest.suite_name('Task 2')
@cg_pytest.suite_weight(0.75)
class TestTask2:

    @cg_pytest.description('Array of length between 1_000-10_000')
    def test_1(self):
        run("testcases/task_2/1_000",
            20, task_2.find_occurrences)

    @cg_pytest.description('Array of length between 10_000-100_000')
    def test_2(self):
        run("testcases/task_2/10_000",
            20, task_2.find_occurrences)

    @cg_pytest.description('Array of length between 100_000-1_000_000')
    def test_3(self):
        run("testcases/task_2/100_000",
            20, task_2.find_occurrences)

    @cg_pytest.description('Array of length between 1_000_000-10_000_000')
    def test_4(self):
        run("testcases/task_2/1_000_000",
            20, task_2.find_occurrences)


@pytest.mark.task_3
@pytest.mark.timeout(15)
@cg_pytest.suite_name('Task 3')
@cg_pytest.suite_weight(1)
class TestTask3:

    @staticmethod
    def run(testcase: str, time_limit: float,
            func: Callable[[List[int]],
                           Union[int, bool]]):

        # Open test files and prepare input/answer data
        input_file = open(f"{root_dir}/{testcase}.in", "r")
        answer = \
            int(open(f"{root_dir}/{testcase}.ans", "r").readline().rstrip())

        # Create `input_l: list[tuple[int,int,int]]` from the test file data
        data: List[str] = input_file.readline().split(' ')
        input_l: List[int] = [int(d) for d in data]

        # Run the `sort` function and measure execution time
        start_time = time.time()
        result: int = func(input_l)
        end_time = time.time()

        # Check that the execution is not above limit
        exec_time = end_time - start_time
        if exec_time > time_limit:
            raise error.Timeout(time_limit, exec_time)
        log.info(f'Call to {func.__name__} took {exec_time}s')

        # Check that `sort` returned
        if result is None:
            raise error.NoOutput()

        # Check that return is list[int]
        if not isinstance(result, int):
            raise error.WrongType(int)

        # Check answer
        if result != answer:
            raise error.WrongAnswer(result, answer)

    @cg_pytest.description('Array of length 1_000')
    def test_1(self):
        self.run("testcases/task_3/1_000",
                 20, task_3.is_min_heap)

    @cg_pytest.description('Array of length 10_000')
    def test_2(self):
        self.run("testcases/task_3/10_000",
                 20, task_3.is_min_heap)

    @cg_pytest.description('Array of length 100_000')
    def test_3(self):
        self.run("testcases/task_3/100_000",
                 20, task_3.is_min_heap)

    @cg_pytest.description('Array of length 1_000_000')
    def test_4(self):
        self.run("testcases/task_3/1_000_000",
                 20, task_3.is_min_heap)
